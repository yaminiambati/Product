package org.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import org.capgemini.model.Product;
import org.capgemini.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class MyController {
	@Autowired
	private ProductService productService;
	private Product product;
	@RequestMapping("/")
	public String getProductPage(ModelMap map) {
		List<Product> products = productService.getProduct();
		if(product!=null)
			map.put("product", product);
		else
			map.put("product", new Product());
		return "Product";
	}
	
	@RequestMapping("update/{productId}")
	public String updateproduct(@PathVariable("productId") Integer proId){
		product=productService.findProduct(proId);
		return "redirect:/";
	}
	
	@RequestMapping("/updateProduct")
	public String updateProduct(@ModelAttribute("prods") Product product1) {
		if(product1!=null) {
			productService.update(product1);
			System.out.println(product1);
			product=null;
			}
			return "redirect:/";
		}
}

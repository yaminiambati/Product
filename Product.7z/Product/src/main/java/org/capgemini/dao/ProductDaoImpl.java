package org.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.capgemini.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
@Transactional
public class ProductDaoImpl implements ProductDao{
	@PersistenceContext
	private EntityManager em; 

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		List<Product> products = em.createQuery("from Product").getResultList();
		return products;
	}

	@Override
	public Product findProduct(Integer productId) {
		// TODO Auto-generated method stub
		Product product= em.find(Product.class, productId);
		return product;
	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub
		if(product.getProductId()!=0)
			em.merge(product);
		else
			em.persist(product);
	}
		
	}


package org.capgemini.dao;

import java.util.List;

import org.capgemini.model.Product;
public interface ProductDao {
	public List<Product> getProduct();
	public Product findProduct(Integer productId);
	public void update(Product product);

}

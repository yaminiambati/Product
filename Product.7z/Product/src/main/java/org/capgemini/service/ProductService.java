package org.capgemini.service;

import java.util.List;

import org.capgemini.model.Product;

public interface ProductService {
	
	public List<Product> getProduct();
	public Product findProduct(Integer productId);
	public void update(Product product);

}
